@echo off
cd /d "%~dp0"
echo Installing GTAMP v1.6.0 hook...
set /p TARGET=Path to your launcher folder (has resources\): 
if not exist "%TARGET%\resources\native\" (
  echo ERROR: %TARGET%\resources\native not found
  pause
  exit /b 1
)
copy /Y gtamp_hook.dll "%TARGET%\resources\native\"
copy /Y gtamp_injector.exe "%TARGET%\resources\native\"
if exist app.asar copy /Y app.asar "%TARGET%\resources\"
echo Done. Restart launcher. Log must say v1.6.0
pause
